<style type="text/css">
    .input-box-select .form-control {
    	width: 215px;
	}
	.input-box-select span {
		display: none;
	}
	#ui-id-1 {
		    width: 200px;
    background-color: #fff;
	}
</style>

  <div class="banner">
    <div class="container">
        <div class="banner-left">           
		<?php 
			$cat = $this->user->get_record_by_field_name_all_record_order_by_title_asc('tbl_category','id',$param['course_category']);
			$this->db->order_by('countries_name','ASC');
			$country = $this->user->get_record_by_field_name_all_record('countries','countries_id',$param['country_id']);
		?>
        <h1>Online Courses</h1>
        <ul class="breadcrumb">
            <li><a href="#<?php //echo site_url();?>"><?php if(!empty($cat)){ echo $cat[0]['cat_name']; }else{ ?>All Professions <?php } ?></a></li>
            <li><?php if(!empty($country)){ echo $country[0]['countries_name']; }else{ ?>International<?php } ?></li>
        </ul>
        </div>
    </div>
</div>

<?php $this->load->view("pages/topheaderads")?>
<?php $cat = $this->user->get_record_by_field_name_all_record_order_by_title_asc('tbl_category','status',1);
	$this->db->order_by('countries_name','ASC');
    $countries = $this->user->get_countries(); ?>

<div class="innerContent">
<div class="container">
  	<div class="row">
        <div class="col-md-8">
				<h3 class="border-title text-left"> <?php if($param['course_category']!='' or  $param['country_id']!='') {  echo 'Featured courses'; }else{	echo 'Latest courses'; } ?> </h3>
       			
                <div class="search-date" style="display:block">
       				<form id="courseform" class="course-search" action="<?php echo base_url(); ?>pages/courses">
					<div class="input-box-select">
						<input type="text" class="form-control" name="course_title" id="course_title" placeholder="ENTER COURSE TITLE" value="<?php echo $_REQUEST['course_title']; ?>" >
					</div>
					<div class="input-box-select">
						<!-- <div class="selection-box "> -->
							<select name="category" class="form-control" id="dropDown">
								<option value="" selected="">PROFESSION</option>
								
								<?php foreach ($cat as $key => $value) { ?>
			            		<option <?php if($value['id']==$param['course_category']){ echo "selected"; } ?> value="<?php echo $value['id']?>"><?php echo $value['cat_name'];?></option>
			            		<?php } ?> 
							</select>
						<!-- </div> -->
					</div> 
					<div class="input-box-select">
					    <!-- <div class="selection-box "> -->
							<select name="country" class="form-control" id="dropDown">
								<option value="" >COUNTRY</option>
								
								<?php foreach ($countries as $country) { ?>
								<option  <?php if($country['countries_id']==$param['country_id']){ echo "selected"; } ?> value="<?php echo $country['countries_id']?>"><?php echo $country['countries_name'];?></option>
								<?php } ?> 							
							</select>
						 <!-- </div> -->
					</div> 
					<div class="input-box-select">
						<a href="javascript:void(0)" onclick="jQuery('#courseform').submit();" class="btn search"><i class="fa fa-search" aria-hidden="true"></i> SEARCH</a>
					</div>
					</form>
				</div>

                <div class="row" id="containerp">
				<?php   if(count($featured)){
							foreach ($featured as $key => $value) {
							
						$providername = $this->db->get_where('tbl_user',array('id'=>$value['user_id']))->row_array();
						$Lessons = $this->db->get_where('tbl_lesson',array('course_id'=>$value['id']))->result_array(); 
						$country = $this->db->get_where('countries',array('countries_id'=>$value['country_id']))->row_array()['countries_name'];
		                   // $c_review=$this->db->where(array('course_id'=>$value['id']))->get('tbl_course_review')->result_array();
		                $resa=$this->db->query("SELECT SUM(star_mark) AS one_s  FROM tbl_course_review where star_mark = 1 and course_id='".$value['id']."'")->row_array();
		                $resb=$this->db->query("SELECT SUM(star_mark) AS two_s  FROM tbl_course_review where star_mark = 2 and course_id='".$value['id']."'")->row_array();
		                $resc=$this->db->query("SELECT SUM(star_mark) AS three_s  FROM tbl_course_review where star_mark = 3 and course_id='".$value['id']."'")->row_array();
		                $resd=$this->db->query("SELECT SUM(star_mark) AS four_s  FROM tbl_course_review where star_mark = 4 and course_id='".$value['id']."'")->row_array();
		                $rese=$this->db->query("SELECT SUM(star_mark) AS five_s  FROM tbl_course_review where star_mark = 5 and course_id='".$value['id']."'")->row_array();
						  
						$ss=$rese['five_s'] + $resd['four_s']+ $resc['tthree_s'] + $resb['two_s']+ $resa['one_s'];
						if($ss){						
							$avg=round(((5 * $rese['five_s']) + (4*$rese['four_s'])  + (3*$rese['three_s']) + (2*$rese['two_s']) + (1*$rese['one_s'])) / ($ss));
						}else{
							$avg=0;
						} //echo $avg; ?>
            	<div class="col-md-4 col-sm-6 col-xs-6" >
                	<div class="course-item">
						<div class="course-double">
					<?php if($value['paid_status']==2)
							{ ?>
                               <div class="corner"></div>
                               <span class="corner-text">featured</span>
					<?php   }  ?>
					
                                <a href="<?php echo site_url('pages/course_details/'.$value['id'].'');?>" class="course-image">
                                <img src="<?php echo ASSETS_URL?>images/uploads/<?php echo $value['course_photo'];?>" alt=""></a>

                                <div class="dt-sc-course-details">
                                	<a href="<?php echo site_url('pages/course_details/'.$value['id'].'');?>"><div class="course-price">$<?php echo floatval($value['total']); ?></div></a>
							    	<h5><a href="<?php echo site_url('pages/course_details/'.$value['id'].'');?>" title="<?php echo $value['course_title'];?>"><?php echo $value['course_title'];?></a></h5>
									<div class="clear-line"> </div>
									<p>By : <?php echo $providername['name'];?><br>
                                    Country :  <?php echo $country;?></p>

                                    <ul class="course-meta">
                                        <li><a href="<?php echo site_url('pages/course_details/'.$value['id'].'');?>"><?php echo $value['cat_name']; ?></a></li>
                                        <li><?php echo count($Lessons);?> Lessons</li>
                                    </ul>

                        <div class="course-data">
                            <div class="course-duration"><i class="fa fa-list-ol"> </i> CE Units <?php echo $value['units'];?></div>
                                <div class="post-ratings">
                                    <?php for($i=1;$i<=5;$i++){
						                     if($i<=$avg)
											 { 
											 	?> <i class="fa fa-star" aria-hidden="true"></i> <?php
											 }else
											 { 
											 	?> <i class="fa fa-star-o" ></i> <?php
											 } 
										  } ?>
                                </div>
                        </div>
					</div>
		        </div>
			</div>
        </div>
				<?php // } ?>
            <?php } }else { ?> <p>Record not found.</p> <?php	}	  ?>
	</div>

		<?php //$this->load->view("pages/middilsectionads")?>

		
		<?php if($param['course_category']!='' or  $param['country_id']!='')
				{  ?>
                
            <hr><div class="row">
                    <div class="col-md-12">
						<h3 class="border-title text-left">Regular Listing</h3>
				<?php if(count($freecourse))
						{ ?>
                        <div class="training-semi-slider-6 pagi-above">
						<?php foreach ($freecourse as $key => $value) { ?> 
		                        <div class="item">
		                            <div class="training-semi">
		                                <div class="new-training-box">
		                                    <a href="<?php echo site_url('pages/course_details/'.$value['id'].'');?>">
		                                        <div class="training-box_overlay"></div>
		                                        <div class="training-box-image">
		                                            <img src="<?php echo ASSETS_URL?>images/uploads/<?php echo $value['course_photo'];?>" alt="">
		                                        </div>
		                                        <div class="training-box-caption">
		                                            <h5 class="training-box_title"><?php echo $value['course_title'];?></h5>
		                                            <div class="training-box_text"><?php echo $value['cpdprovider'];?></div>
		                                        </div>
		                                    </a>
		                                </div>
		                            </div>
		                        </div>
						<?php } ?> 
                		</div>
					   <?php } else { ?>
							 <div class="pagi-above">Record not found.</div>
							<?php } ?>
                    </div>
                </div>
              <?php } ?>
            </div>
           <?php  $this->load->view('pages/sidebar'); ?>
        </div>
        <div class="training-semi-slider-6 pagi-above">
					<?php $this->load->view("pages/bottomfooterads")?>
            	</div>
    </div>
</div>

<?php 
$this->db->select('course_title')->where(array('insititution_id'=>'0','status'=>'1'));
$name = $this->db->get('tbl_course')->result_array(); 
 
$names = array_column($name, 'course_title');
//echo json_encode($names); ?>

<!-- <script src = "https://code.jquery.com/jquery-1.10.2.js"></script> -->


