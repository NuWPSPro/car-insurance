 
<?php foreach ($evaluation as $key => $value) { ?> 
  
<p class="question"><b> Q. <?php echo $key+1; ?> <?php  echo $value['evaluation_question']; ?></b></p>

<p><?php if($value['question_type'] == 1){ ?>
	 <div class="step-wise-query"> 
                <!-- Rating section start -->
                <div class="container">
                    <style>
                        .glyphicon { margin-right:5px; color:#007ded;}
                        .rating .glyphicon {font-size: 22px;}
                        .rating-num { margin-top:0px;font-size: 54px; }
                        .progress { margin-bottom: 5px;}
                        .progress-bar { text-align: left; }
                        .rating-desc .col-md-3 {padding-right: 0px;}
                        .sr-only { margin-left: 5px;overflow: visible;clip: auto; }
                    </style>
                    <div class="row">
                        <div class="col-xs-12 col-md-6">
                            <div class="well well-sm">
                                <div class="row">
                                    <div class="col-xs-12 col-md-12">
                                        <div class="row rating-desc">
                                            <div class="col-xs-3 col-md-3 text-right">
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                            </div>
                                            <div class="col-xs-8 col-md-9">
                                                <div class="progress progress-striped">
								
										<?php 
										
										$fivestarwhere = array('training_id'=>$tr_id,'speaker_id'=>$idd,'question_id'=>$value['id'],'star_mark'=>5);
										 // print_r($fivestarwhere);die;
										$fivestar      = $this->user->get_record_by_field_name_all_record11('tbl_training_review',$fivestarwhere);


										if(!empty($fivestar)){
										$FivetotalFiveStar = 0;
										$FivetotalFiveStarPercentage = 0;
										foreach ($fivestar as $key => $value) {
										$FivetotalFiveStar = $FivetotalFiveStar + $value['star_mark'];
										} 

										$FivetotalFiveStarPercentage = $FivetotalFiveStar * count($fivestar) / 100;
										$Fiveexact1 = ceil($FivetotalFiveStarPercentage);
										if($Fiveexact1 <= 10){
										$FiveexactPercent1 = 10;
										}
										} 
										?>

                                                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="20"
                                                        aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $FiveexactPercent1; ?>%">
                                                   <span class="sr-only"><?php echo $Fiveexact1; ?>%</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end 5 -->
                                            <div class="col-xs-3 col-md-3 text-right">
                                            <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                            </div>
                                            <div class="col-xs-8 col-md-9">
                                                 <div class="progress progress-striped">
								
										<?php 
										
										$fivestarwhere = array('training_id'=>$tr_id,'speaker_id'=>$idd,'question_id'=>$value['id'],'star_mark'=>4);
										 
										$fivestar      = $this->user->get_record_by_field_name_all_record11('tbl_training_review',$fivestarwhere);


										if(!empty($fivestar)){
										$FivetotalFiveStar = 0;
										$FivetotalFiveStarPercentage = 0;
										foreach ($fivestar as $key => $value) {
										$FivetotalFiveStar = $FivetotalFiveStar + $value['star_mark'];
										} 

										$FivetotalFiveStarPercentage = $FivetotalFiveStar * count($fivestar) / 100;
										$Fiveexact2 = ceil($FivetotalFiveStarPercentage);
										if($Fiveexact2 <= 10){
										$FiveexactPercent2 = 10;
										}
										} 
										?>

                                                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="20"
                                                        aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $FiveexactPercent2; ?>%">
                                                   <span class="sr-only"><?php echo $Fiveexact2; ?>%</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end 4 -->
                                            <div class="col-xs-3 col-md-3 text-right">
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                            </div>
                                            <div class="col-xs-8 col-md-9">
                                                  <div class="progress progress-striped">
								
										<?php 
										
										$fivestarwhere = array('training_id'=>$tr_id,'speaker_id'=>$idd,'question_id'=>$value['id'],'star_mark'=>3);
										 
										$fivestar      = $this->user->get_record_by_field_name_all_record11('tbl_training_review',$fivestarwhere);


										if(!empty($fivestar)){
										$FivetotalFiveStar = 0;
										$FivetotalFiveStarPercentage = 0;
										foreach ($fivestar as $key => $value) {
										$FivetotalFiveStar = $FivetotalFiveStar + $value['star_mark'];
										} 

										$FivetotalFiveStarPercentage = $FivetotalFiveStar * count($fivestar) / 100;
										$Fiveexact3 = ceil($FivetotalFiveStarPercentage);
										if($Fiveexact3 <= 10){
										$FiveexactPercent3 = 10;
										}
										} 
										?>

                                                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="20"
                                                        aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $FiveexactPercent3; ?>%">
                                                   <span class="sr-only"><?php echo $Fiveexact3; ?>%</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end 3 -->
                                            <div class="col-xs-3 col-md-3 text-right">
                                                <span class="glyphicon glyphicon-star"></span>
                                                <span class="glyphicon glyphicon-star"></span>
                                            </div>
                                            <div class="col-xs-8 col-md-9">
                                                 <div class="progress progress-striped">
								
										<?php 
										
										$fivestarwhere = array('training_id'=>$tr_id,'speaker_id'=>$idd,'question_id'=>$value['id'],'star_mark'=>2);
										 
										$fivestar      = $this->user->get_record_by_field_name_all_record11('tbl_training_review',$fivestarwhere);


										if(!empty($fivestar)){
										$FivetotalFiveStar = 0;
										$FivetotalFiveStarPercentage = 0;
										foreach ($fivestar as $key => $value) {
										$FivetotalFiveStar = $FivetotalFiveStar + $value['star_mark'];
										} 

										$FivetotalFiveStarPercentage = $FivetotalFiveStar * count($fivestar) / 100;
										$Fiveexact4 = ceil($FivetotalFiveStarPercentage);
										if($Fiveexact4 <= 10){
										$FiveexactPercent4 = 10;
										}
										} 
										?>

                                                    <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="20"
                                                        aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $FiveexactPercent4; ?>%">
                                                   <span class="sr-only"><?php echo $Fiveexact4; ?>%</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end 2 -->
                                            <div class="col-xs-3 col-md-3 text-right">
                                                <span class="glyphicon glyphicon-star"></span>
                                            </div>
                                            <div class="col-xs-8 col-md-9">
                                                  <div class="progress progress-striped">
								
										<?php 
										
										$fivestarwhere = array('training_id'=>$tr_id,'speaker_id'=>$idd,'question_id'=>$value['id'],'star_mark'=>1);
										 
										$fivestar      = $this->user->get_record_by_field_name_all_record11('tbl_training_review',$fivestarwhere);


										if(!empty($fivestar)){
										$FivetotalFiveStar = 0;
										$FivetotalFiveStarPercentage = 0;
										foreach ($fivestar as $key => $value) {
										$FivetotalFiveStar = $FivetotalFiveStar + $value['star_mark'];
										} 

										$FivetotalFiveStarPercentage = $FivetotalFiveStar * count($fivestar) / 100;
										$Fiveexact5 = ceil($FivetotalFiveStarPercentage);
										if($Fiveexact5 <= 10){
										$FiveexactPercent5 = 10;
										}
										} 
										?>

                                                    <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="20"
                                                        aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $FiveexactPercent5; ?>%">
                                                   <span class="sr-only"><?php echo $Fiveexact5; ?>%</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end 1 -->
                                        </div>
                                        <!-- end row -->
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Rating section start End-->
     </div>
	<?php }
	 if($value['question_type'] == 2){ ?>
	<?php 	$where   = array('training_id'=>$tr_id,'speaker_id'=>$idd);
			$review  = $this->user->getuniqecomments('tbl_training_review',$where);
			if(!empty($review)){  ?>
		<?php  	foreach ($review as $key => $val) {
			if($key==0){ $key = 1; }
					if($val['comments'] !=""){ echo'<p class="comments-section">'.$key.'. '.$val['comments'].'</p>'; } 
				}
			} ?>

<style type="text/css">
	p.comments-section {
	    margin-left: 24px;
	}
</style>

 <?php } ?>
</p>
<?php }  ?>