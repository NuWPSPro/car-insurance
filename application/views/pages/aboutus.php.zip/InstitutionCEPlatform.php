<section class="iceproject-herobaner">
  
        <div class="ice-project" style="background-image: url(<?php echo ASSETS_URL.'images/webpages/allprofessionals.jpg';?>);">
            <div class="container">
                <div class="iiceproject-herobaner-contentbox">
                    <div class="ice-project-content">
                        <h1>ICE Platform</h1>
                        <p class="ice-page-content">Institutions Continuing Education (ICE) Platform</p>
                        <p><strong>Empowering staff through continuing education<br> to deliver quality service.</p>
                        <div class="elementor-widget-button pl-0">
                                <a href="https://ceonpoint.com/web/institution-001-62" target="_blank">View Demo</a>
                                <a href="https://ceonpoint.com/users/signup/institution" class="widget-button">Register Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      <div class="container">
        <div class="ice-componentspanel">
                    <h2>ICE PLATFORM COMPONENTS</h2>
                    <p>We take care of the online platform so you can focus on<br>
                    creating unlimited online courses and training.</p>
            <div class="ice-components-box">
                    <a href="#" data-toggle="modal" data-target="#iceWebpage">
                        <img class="ice-register_pro" src="https://www.ceonpoint.com/assets/images/webpages/img2.png">
                        <div class="ice-components-boxinfo">
                        <span>ice webpage</span>
                        <p>Instant webpage that contains online courses & training.</p>
                        </div>
                    </a>
                    <a href="#" data-toggle="modal" data-target="#iceSoftware">
                        <img class="ice-register_pro" src="https://www.ceonpoint.com/assets/images/webpages/softwareresize2.png">
                        <div class="ice-components-boxinfo">
                        <span>ice software</span>
                          <p>Manages tha institutions ICE Project form different users.</p>
                        </div>
                    </a>
                    <a href="#" data-toggle="modal" data-target="#iceMobile">
                        <img class="ice-register_pro" src="https://www.ceonpoint.com/assets/images/webpages/img1.png">
                        <div class="ice-components-boxinfo">
                        <span>ice mobile app</span>
                          <p>Making your online courses & training avalible in cellphones.</p>
                          </div>
                    </a>
            </div>  
        </div>
    </div>
</section>

<section class="streamline-panel">
  <div class="streamline-videobox" style="background-image: url(<?php echo ASSETS_URL.'images/webpages/img3.png';?>);">
         <div class="container">
          <div class="streamline-videoinfo">
            
            <h4>streamline</h4>
            <p> All CE courses (online and training) from different departments and authors
                <br> will be in one webpage that are <br> available and accessible 24/7 to all staff of your institution.</p>

            <div class="video-icon-popup">
                <a href="#" data-toggle="modal" data-target="#videoModal" data-thevideo="http://www.youtube.com/embed/loFtozxZG0s"><i class="fa fa-play" aria-hidden="true"></i></a>
            </div>
          </div>
          </div>
        </div>

        <div class="container">
        <div class="ice-soft-streamline-lin">
            <div class="row">
                <div class="col-md-12">
                    <h4>ice Platform users</h4>
                    <p class="text-center">See what individual users of ICE Platform can do to deliver continuing education towards quality service.</p>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="ice-professionals-icons">
                        <a href="#" data-toggle="modal" data-target="#iceAdminModal">
                            <img class="ice-register_pro" src="<?php echo ASSETS_URL.'images/institution.png';?>">
                            <span>Administrator</span>
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="ice-professionals-icons">
                        <a href="#" data-toggle="modal" data-target="#iceProviderModal">
                            <img class="ice-register_pro" src="<?php echo ASSETS_URL.'images/provider.png';?>">
                            <span>CE Provider</span>
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="ice-professionals-icons">
                        <a href="#" data-toggle="modal" data-target="#iceAuthorModal">
                            <img class="ice-register_pro" src="<?php echo ASSETS_URL.'images/author1.png';?>">
                            <span>Author/Presenter</span>
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="ice-professionals-icons">
                        <a href="#" data-toggle="modal" data-target="#iceStaffModal">
                            <img class="ice-register_pro" src="<?php echo ASSETS_URL.'images/webpages/professional.png';?>">
                            <span>Staff</span>
                        </a>
                    </div>
                </div>
            </div>
    </div>
  </div>
</section>

<section class="ice-packagespanal">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h2>ICE PLATFORM <span>PACKAGES</span></h2>
        <div class="minice-packages">
          <div class="ice-packagesbox">
            <div class="ice-packages-title">PACKAGES 1</div>
              <div class="ice-packages-infobox">
              <p>USE OF ONLINE COURSE<br> MANAGEMENT SOFTWARE<br>(OCMS)</p>
                <h1>$1.25</h1>
                <span>staff/month/
                  unlimited online courses</span>
                  <p>(paid annually)</p>

                  <a href="<?php echo base_url('users/signup/institution') ?>" class="register-btn">REGISTER NOW</a>
              </div>

             <div class="ice-packages-features">
                  <h3>FEATURES</h3>
               <ul>
                 <li> Upload unlimited online courses</li>
                 <li>Issue digital certificates</li>
                 <li>Archive of all online courses</li>
                 <li>Archive of digital certificates</li>
                 <li>Online evaluation of courses</li>
               </ul>
             </div>
          </div>



          <div class="ice-packagesbox ice-packages-boxtow">
            <div class="ice-packages-title">PACKAGES 2</div>
              <div class="ice-packages-infobox">
              <p>USE OF TRAINING<br> MANAGEMENT SOFTWARE<br> (TMS)</p>
                <h1>$1</h1>
                <span>certificate/training only</span>
                <span>NO</span>
                     
                  <strong>MONTHLY SUBSCRIPTION</strong>

                  <a href="<?php echo base_url('users/signup/institution') ?>" class="register-btn">REGISTER NOW</a>
              </div>

             <div class="ice-packages-features">
                  <h3>FEATURES</h3>
               <ul>
                  <li>Upload unlimited training</li>
                  <li>Use Training Management Software</li>
                  <li>Issue digital certificates</li>
                  <li>Online registration</li>
                  <li>Online payment of registration fee</li>
                  <li>Archive of all training</li>
                  <li>Archive of digital certificates</li>
                  <li>Online evaluation of training</li>
                  <li>Digital training invitation</li>
                  <li>Online</li>
               </ul>
             </div>
          </div>

          <div class="ice-packagesbox ice-packages-boxthree">
            <div class="ice-packages-title">PACKAGES 3</div>
              <div class="ice-packages-infobox">
              <p>IF YOU USE PACKAGE 1 &<br> REGISTER 500 STAFF OR MORE,<br> YOU CAN USE PACKAGE 2 FOR FREE</p>
                <h1>$1.25</h1>
                <span>staff/month/Unlimited online courses</span>
                  <p>(paid annually)</p>

                  <a href="<?php echo base_url('users/signup/institution') ?>" class="register-btn">REGISTER NOW</a>
              </div>

             <div class="ice-packages-features">
                  <h3>FEATURES</h3>
               <ul>
                 <li>Both features of package 1 & 2</li>
               </ul>
             </div>
          </div>

        </div>
      </div>
    </div>
    
  </div>
</section>

<section class="ice-project-subscrib ice-subscribpanel" style="font-family: 'Poppins', sans-serif;">
    <div class="container">
      <div class="ice-subscribinnr">
        <div class="ice-project-main" style="overflow: hidden;">
            <h2 class="pull-left">ICE Platform Subscribers:</h2>
            <a href="https://ceonpoint.com/pages/Institutionspage" class="pull-right btn btn-success mt-2">View All Institutions</a>
        </div>
        <div class="ice-slider">
            <?php foreach($ins_list as $key => $value){ 
            $country = $this->db->get_where('countries',array('countries_id'=>$value['country']))->row_array()['countries_name']; ?>
                <div class="item">

                    
                    
                    <div class="training-semi training-semi-big">
                        <div class="new-training-box">
                            <a href="<?php echo base_url('web/').$value['insititution_id']; ?>">
                                <div class="training-box_overlay"></div>
                                <div class="training-box-image ins_images">

                                    <?php    if($value['backimage']==""){
                                                $img = "dummy-profile.jpg";
                                             } else {
                                                $img = $value['backimage'];
                                            }  ?>
                                <img src="<?php echo ASSETS_URL.'images/uploads/'.$img;?>" alt="<?php echo $value['name']?>" title="<?php echo $value['name']?>">
                                </div>
                                <div class="training-box-caption">
                                    <h5 class="training-box_title"><?php echo $value['name']; ?></h5>
                                    <div class="training-box_text"><?php echo $country; ?></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    
                    
                </div>
            <?php } ?>
        </div>
      </div>
    </div>
</section>

<a href="#" id="scroll"><span></span></a>  

<!-- The ICE Webpage Modal -->
  <div class="modal fade icecomponents-modal" id="iceWebpage">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header text-center">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="ice-professionals-icons">
                <h1>ICE WEBPAGE</h1>
            </div>           
        </div>
        <!-- Modal body -->
        <div class="modal-body">
          <ul>
                <li>Title and subtitle with photo background</li>
                <li>Online course listing</li>
                <li>Log-in and register</li>
                <li>Training/Seminars listing</li>
                <li>CE providers section</li>
                <li>Authors/Presenters section</li>
                <li>News/Blog section</li>

          </ul>
          <img src="<?php echo ASSETS_URL.'images/webpages/img2.png'; ?>">
        </div>
      </div>
    </div>
  </div>
<!-- The ICE Webpage Modal -->
  <div class="modal fade icecomponents-modal" id="iceSoftware">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header text-center">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="ice-professionals-icons">
                <h1>ICE SOFTWARE</h1>
                <h2>(ICE-MS)</h2>
            </div>           
        </div>
        <!-- Modal body -->
        <div class="modal-body">
          <ul>
                <li>Customize your webpage title section</li>
                <li>Set annual training period & targets</li>
                <li>View real-time accomplishments</li>
                <li>Upload unlimited online courses and training</li>
                <li>Issue digital certificates for online courses & training</li>
                <li>Use Training Management Software (TMs)</li>
                <li>Archive your previous annual target and accomplishment</li>
                <li>Register unlimited CE Providers and authors</li>
                <li>Register unlimited staff</li>
                <li>Track CE compliance of staff</li>

          </ul>
          <img src="<?php echo ASSETS_URL.'images/webpages/softwareresize2.png'; ?>">
        </div>
      </div>
    </div>
  </div>
<!-- The ICE Webpage Modal -->
  <div class="modal fade icecomponents-modal" id="iceMobile">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header text-center">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="ice-professionals-icons">
                <h1>ICE MOBILE APP</h1>
            </div>           
        </div>
        <!-- Modal body -->
        <div class="modal-body">
        <p>Contains the following sections:</p>
          <ul>
                <li>Title and subtitle with photo background</li>
                <li>Online course listing</li>
                <li>Training/Seminars listing</li>
          </ul>
          <img src="<?php echo ASSETS_URL.'images/webpages/img1.png'; ?>">
        </div>
      </div>
    </div>
  </div>

<!-- The ICE Admin Modal -->
  <div class="modal fade" id="iceAdminModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header text-center">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="ice-professionals-icons">
                <a href="#">
                    <img class="ice-register_pro" src="<?php echo ASSETS_URL.'images/institution.png'; ?>">
                    <span>Administrator</span>
                </a>
            </div>           
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <ul>
                <li>Edit webpage photo, title and subtitle</li>
                <li>Send institution code to the sub-institution and CE Providers</li>
                <li>Set training period</li>
                <li>Consolidate all set targets and performance reports of all CE Providers</li>
                <li>Approve sub-institution and CE Provider’s account</li>
                <li>Enable or disable accounts of sub-institution, CEP’s, Authors and staff</li>
                <li>Can check all the staff compliance for continuing education</li>
                <li>Track all payments of the CEP to activate staff</li>
                <li>Archive all targets and performance reports</li>
                <li>Track all digital certificates of the staff</li>
          </ul>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>

<!-- The ICE Provider Modal -->
  <div class="modal fade" id="iceProviderModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header text-center">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="ice-professionals-icons">
                <a href="#">
                    <img class="ice-register_pro" src="<?php echo ASSETS_URL.'images/provider.png';?>">
                    <span>CE Provider</span>
                </a>
            </div>           
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <ul>
                <li>Set annual training targets.</li>
                <li>Real-time accomplishment report.</li>
                <li>Review and publish  submitted online courses of authors.</li>
                <li>Create and publish training.</li>
                <li>Send CEP code to the authors.</li>
                <li>Approve authors or presenters account.</li>
                <li>Register unlimited number of staff.</li>
                <li>Activate the staff account to have access to online courses and training at Institution CE Webpage.</li>
                <li>Set required CE Units of staff.</li>
                <li>Track staff  CE compliance.</li>
                <li>Keep records of all digital certificates issued from online courses and training.</li>
          </ul>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>

<!-- The ICE Author Prenster Modal -->
  <div class="modal fade" id="iceAuthorModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header text-center">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="ice-professionals-icons">
                <a href="#">
                    <img class="ice-register_pro" src="<?php echo ASSETS_URL.'images/author1.png';?>">
                    <span>Author/Presenter</span>
                </a>
            </div>           
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <ul>
                <li>Create online courses and submit to CE provider.</li>
            </ul>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>

<!-- The ICE Author Prenster Modal -->
  <div class="modal fade" id="iceStaffModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header text-center">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <div class="ice-professionals-icons">
                <a href="#">
                    <img class="ice-register_pro" src="<?php echo ASSETS_URL.'images/webpages/professional.png';?>">
                    <span>Staff</span>
                </a>
            </div>           
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <ul>
                <li>Connect to institution using the institution. CEP and staff code.
                <li>Take unlimited online courses.</li>
                <li>Register online for training/seminars.</li>
                <li>Receive digital certificates that will be recorded automatically in the institution database.</li>
                <li>Automatically in the institution database.</li>
                <li>Send other certificates to institution database.</li>
                <li>Track status of CE compliance.</li>
            </ul>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://ceonpoint.com/assets/js/owlcarousel/owl.carousel.js"></script>
    <script>
    $('.ice-slider').owlCarousel({
			loop: true,
            margin: 20,
			nav: true,
			dots: false,
			autoplay: true,
			pagination: true,
			paginationSpeed: 600,
			smartSpeed: 1000,
			autoplayTimeout: 5000,
			responsive: {
				0: {
					items: 1
				},
				767: {
					items: 2
				},
				992: {
					items: 3
				},
				1000: {
					items: 4
				},
				1200: {
					items: 4
				}
			}
		});
    </script>









