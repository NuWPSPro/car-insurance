<style type="text/css">
    .input-box-select .form-control {
    width: 220px;
    }
</style>
<?php $current_country = $this->session->userdata('current_country'); ?>
<div class="service-process" style=" background: #e5e5e5;">
    <div class="container">
        
        <div class="row">

            <div class="col-sm-4 item">
                <div class="home-icon-certificate">
                    <img src="<?php echo ASSETS_URL.'images/home-cartificate.png'; ?>">
                    <!-- <i class="fa fa-graduation-cap"></i>  -->
                </div>
                <div class="item-content">
                    <h3>Digital Certificate Storage</h3>
                    <p>Store unlimited digital & non-digital certificates from your online courses or training.</p>
                </div>
            </div>

            <div class="col-sm-4 item home-icon">
                <div class="home-icon-search">
                    <img src="<?php echo ASSETS_URL.'images/home-search.png'; ?>">
                    <!-- <i class="fa fa-graduation-cap"></i>  -->
                </div>
                <div class="item-content">
                    <h3>CE Units Tracker</h3>
                    <p>Keep you updated of your required, Obtained & Needed CE Units for license renewal or performance appraisal.</p>
                </div>
            </div>

            <div class="col-sm-4 item">
                <div class="home-icon-message">
                    <img src="<?php echo ASSETS_URL.'images/home-message.png'; ?>">
                    <!-- <i class="fa fa-graduation-cap"></i>  -->
                </div>
                <div class="item-content">
                    <h3>Electronic Reporting</h3>
                    <p>Report directly your certificates to your regulatory board and employer </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /* 
<section class="main-addspace">
        <div class="container">
            <div class="main-addspace-box">
        <?php   if(!empty($current_country)){$this->db->where('tbl_adv_package_purchased.country',$current_country);}
                $topbanner = $this->advertiseads->getAdvertiserBanner('Top Body');  
                // echo $this->db->last_query(); print_r($topbanner);die;                   
                          if(count($topbanner))
                           {
                               $i=1;
                              foreach($topbanner as $banner)
                              {
                                  if($i>4)
                                  {
                                      break;
                                  }
                                   $i++;
                                   
                                   $this->advertiseads->updateCount($banner['id']);
                                  $size=explode('x',$banner['size']);
                                  ?>
                                        <div class="item">
                                            <div class="main-addspace-iner-box">
                                                <a href="<?php if($banner['website_url']){ echo $banner['website_url'];}else{ echo "#";}?>"><img src="<?php echo ASSETS_URL; ?>upload/<?php echo $banner['banner_image'];?>" width="<?php echo $size[0]; ?>" height="<?php echo $size[1]; ?>" alt=""></a>
                                            </div>
                                        </div>
                                    
                            <?php                           
                                 
                              }
                           }else
                           {
                               ?>
              
                    <a href="#">
                        <div class="item">
                            <div class="main-addspace-iner-box">
                                <img src="<?php echo ASSETS_URL.'images/advertise/new-300-x-50.jpg'; ?>" alt="">
                            </div>
                        </div>
                    </a> 
                            
                   
                    <a href="#">
                        <div class="item">
                            <div class="main-addspace-iner-box">
                                <img src="<?php echo ASSETS_URL.'images/advertise/new-300-x-50.jpg'; ?>" alt="">
                            </div>
                        </div>
                    </a> 
               
               
                    <a href="#">
                        <div class="item">
                            <div class="main-addspace-iner-box">
                                <img src="<?php echo ASSETS_URL.'images/advertise/new-300-x-50.jpg'; ?>" alt="">
                            </div>
                        </div>
                    </a> 
               
              
                    <a href="#">
                        <div class="item">
                            <div class="main-addspace-iner-box">
                                <img src="<?php echo ASSETS_URL.'images/advertise/new-300-x-50.jpg'; ?>" alt="">
                            </div>
                        </div>
                    </a> 
                <?php } ?>
            </div>
        </div>
</section>

*/ ?>


<div class="weOffer">
    <div class="container">
        <div class="row">
            <h1 class="border-title text-center text-uppercase mb-0 pb-0">products and services we OFFER</h1>
            <h4 class="mb-5 text-center">We specialize in continuing education platforms.</h4>
            <div class="owl-carousel-3 nav-button">
            <div class="item">
                <div class="jet-banner-wrapper">
                     <a href="<?php echo base_url()?>pages/cetracker"> 
                        <img src="<?php echo ASSETS_URL.'images/offer-1.jpg'; ?>" alt="PCE-MS" class="jet-banner_img">
                        <div class="jet-banner_content ">
                            <h5 class="jet-banner_title text-uppercase">PCE Platform</h5>
                            <div class="jet-banner_text">Professional Continuing Education (PCE) Platform</div>
                        </div>
                     </a> 
                </div>
                <ul class="jet-banner_list mb-3">
                    <li>Global access to CE courses</li>
                    <li>Access to Institution CE courses</li>
                    <li>PCE- Management Software</li>
                    <li>Professional Webpage</li>
                    <li>Mobile app</li>
                </ul>
                <a href="<?php echo base_url()?>pages/cetracker" class="btn btn-primary">Learn More</a>
            </div>
            <div class="item">
                <div class="jet-banner-wrapper">
                     <a href="<?php echo base_url()?>pages/InstitutionCEPlatform"> 
                        <img src="<?php echo ASSETS_URL.'images/offer-2.jpg'; ?>" alt="ICE-MS" class="jet-banner_img">
                        <div class="jet-banner_content ">
                            <h5 class="jet-banner_title text-uppercase">ICE Platform</h5>
                            <div class="jet-banner_text">Institution Continuing Education (ICE) Platform</div>
                        </div>
                     </a>
                </div>
                <ul class="jet-banner_list mb-3">
                    <li>ICE- Management Software</li>
                    <li>ICE Webpage</li>
                    <li>Mobile app</li>
                </ul>
                <a href="<?php echo base_url()?>pages/InstitutionCEPlatform" class="btn btn-primary">Learn More</a>
            </div>
            <div class="item">
                <div class="jet-banner-wrapper">
                     <a href="<?php echo base_url()?>pages/ceprovideplateform"> 
                        <img src="<?php echo ASSETS_URL.'images/offer-3.jpg'; ?>" alt="CEP-MS" class="jet-banner_img">
                        <div class="jet-banner_content ">
                            <h5 class="jet-banner_title text-uppercase">CEP Platform</h5>
                            <div class="jet-banner_text">Continuing Education Provider Platform</div>
                        </div>
                     </a> 
                </div>
                <ul class="jet-banner_list mb-3">
                    <li>CEP- Management Software</li>
                    <li>CEP Webpage</li>
                    <li>Local & global exposure of your online courses</li>
                    <li>Mobile app</li>
                    <li>Passive income</li>
                </ul>
                <a href="<?php echo base_url()?>pages/ceprovideplateform" class="btn btn-primary">Learn More</a>
            </div>
            <div class="item">
                <div class="jet-banner-wrapper">
                     <a href="<?php echo base_url()?>pages/training_management"> 
                        <img src="<?php echo ASSETS_URL.'images/offer-4.jpg'; ?>" alt="TMS" class="jet-banner_img">
                        <div class="jet-banner_content ">
                            <h5 class="jet-banner_title">TMS</h5>
                            <div class="jet-banner_text">Training Management Software</div>
                        </div>
                     </a> 
                </div>
                <ul class="jet-banner_list mb-3">
                    <li>Instant training webpage</li>
                    <li>Digital invitation to social media</li>
                    <li>Verifiable Digital Certificate</li>
                    <li>Online registration & payment</li>
                    <li>Online training evaluation</li>
                    <li>Printable training report</li>
                    <li>Training sponsors section</li>
                    <li>And more</li>
                </ul>
                <a href="<?php echo base_url()?>pages/training_management" class="btn btn-primary">Learn More</a>
            </div>
            <div class="item">
                <div class="jet-banner-wrapper">
                     <a href="<?php echo base_url()?>pages/cfvalidation"> 
                        <img src="<?php echo ASSETS_URL.'images/offer-5.jpg'; ?>" alt="TMS" class="jet-banner_img">
                        <div class="jet-banner_content ">
                            <h5 class="jet-banner_title">DCS</h5>
                            <div class="jet-banner_text">Digital Certificate Software</div>
                        </div>
                     </a> 
                </div>
                <ul class="jet-banner_list mb-3">
                    <li>Digitalize your certificatesto be issued to recipientsby creating a CEP account orInstitution account.</li>
                    <li>Online verification of digitalcertificates here at :<a href="https://ceonpoint.com/pages/cfvalidation" class="text-primary"> https://ceonpoint.com/pages/cfvalidation</a></li>
                </ul>
                <a href="<?php echo base_url()?>pages/cfvalidation" class="btn btn-primary">Learn More</a>
            </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="onlinecourse-box ">
                    <div class="panel panel-default btn-strip" style="margin-bottom:0;">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="or-text">or</div>
                                <div class="col-md-6 col-sm-6 col-xs-6">
                                    <a class="btn active showSingle" id="active"  target="1">Online courses</a>
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-6">
                                    <a class="btn onlinecourse showSingle" target="2">Training/Seminars</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="elementor-widget-container">
                        <h4>ONLINE COURSES</h4>
                    </div>
                    <div class="or-title">OR</div>
                    <div class="elementor-widget-container white">
                        <h4>TRAINING/SEMINAR</h4>
                    </div> -->
                </div>
            </div>
        </div>

            
        <div class="row">
            <div class="online-latest targetDiv" id="div1">
            
                <h3 class="border-title text-center">LATEST ONLINE COURSES</h3>
                <?php if(count($freecourse) > 0 ){  ?>   
                <div class="online-latest-bttn-box">
                    <form id="courseform" class="searchform" action="<?php echo base_url('pages/courses')?>">
                            <div class="input-box-select">
                                <input type="text" name="course_title" id="course_title" class="form-control" placeholder="ENTER ONLINE COURSE TITLE" value="<?php echo $_REQUEST['course_title']; ?>">
                            </div>
                            <div class="input-box-select">
                                <!-- <div class="selection-box "> -->
                                    <select name="category" class="form-control" id="dropDown">
                                        <option value="" selected="">PROFESSION</option>
                                        
                                        <?php foreach($category as $cate){ ?>
                                        <option value="<?php echo  $cate['id']; ?>"><?php echo  $cate['cat_name']; ?></option>
                                        <?php } ?>  
                                    </select>
                                <!-- </div> -->
                            </div>   

                            <div class="input-box-select">
                                <!-- <div class="selection-box "> -->
                                    <select name="country" class="form-control" id="dropDown" >
                                       <option value="" selected="">COUNTRY</option>
                                    
                                        <?php foreach($countries as $country){?>
                                        <option value="<?php echo  $country['countries_id']; ?>"><?php echo  $country['countries_name']; ?> </option>
                                        <?php } ?>  
                                    </select>
                                <!-- </div> -->
                            </div> 

                        <div class="input-box-select">
                            <a href="javascript:void(0)" onclick="jQuery('#courseform').submit();" class="btn search"><i class="fa fa-search" aria-hidden="true"></i> SEARCH</a>
                        </div>
                    </form>
                    </div>

               
                <div class="owl-carousel-3 nav-button">
                <?php foreach ($freecourse as $key => $value) {
                        $providername = $this->db->get_where('tbl_user',array('id'=>$value['user_id']))->row_array();
                        $Lessons = $this->db->get_where('tbl_lesson',array('course_id'=>$value['id']))->result_array();
                        $categoryname = $this->db->get_where('tbl_category',array('id'=>$value['course_category']))->row_array();  
                        $country = $this->db->get_where('countries',array('countries_id'=>$value['country_id']))->row_array()['countries_name']; ?>
                    
                    <div class="item">
                        <div class="course-item">

                            <div class="course-double">
                              <?php if($value['paid_status']==2) { ?>
                               <div class="corner"></div>
                               <span class="corner-text">featured</span>
                               <?php
                              }
                               ?>
                                <a href="<?php echo site_url('pages/course_details/'.$value['id'].'');?>" class="course-image">
                                
                                 <?php if ($value['course_photo']) { ?>
                                    <img src="<?php echo ASSETS_URL.'images/uploads/'.$value['course_photo'];?>" alt="">
                                <?php } else { ?>
                                    <img src="<?php echo ASSETS_URL.'images/uploads/IMG_1560995024.png';?>" alt="">
                                <?php } ?>
                                
                              </a>

                                <div class="dt-sc-course-details">

                                    <!-- <div class="course-price">$<?php echo $value['price'];?></div> -->
                                    <div class="course-price">$<?php echo floatval($value['total']);?></div>

                                    <h5><a href="<?php echo site_url('pages/course_details/'.$value['id'].'');?>" title="<?php echo $value['course_title'];?>"><?php echo $value['course_title'];?></a></h5>

                                    <div class="clear-line"> </div>

                                    <p>By :  <?php echo $providername['name'];?><br>
                                    Country :  <?php echo $country;?></p>

                                    <ul class="course-meta">
                                        <li><a href="<?php echo site_url('pages/course_details/'.$value['id'].'');?>"><?php echo $categoryname['cat_name'];?></a></li>
                                        <li><?php echo count($Lessons);?> Lessons</li>
                                    </ul>

                                    <div class="course-data">
                                        <div class="course-duration"><i class="fa fa-list-ol"> </i> CE Units  <?php echo $value['units'];?></div>
                                        <div class="post-ratings">
                                        <?php for($i=1;$i<=5;$i++){
                                                 if($i<=$value['rating']){
                                                    echo '<i class="fa fa-star" aria-hidden="true"></i>';
                                                   }else{
                                                    echo '<i class="fa fa-star" aria-hidden="true"></i>';
                                                    } 
                                                 } ?>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>
                    <?php  } ?>   
                </div>
                  <?php  }else{ echo '<center>No Data Found!</center>'; } ?>
            </div>
        </div>
        <?php 
            $where['status'] = 2; //Published
            // $where['featured_from <='] = date('Y-m-d');
            $where['end_date >='] = date('Y-m-d');
            $this->db->or_where(array('insititution_id'=>'0'));
            $seminar = $this->user->get_training($where);
        ?>            
        <div class="row">
            <div class="online-latest targetDiv" id="div2" style="display:none;">
               
                <h3 class="border-title text-center">LATEST TRAINING/SYMPOSIUM/CONVENTION</h3>
                <div class="online-latest-bttn-box">
                    <form id="trainingform" class="searchform" action="<?php echo base_url('pages/training')?>">
                            <div class="input-box-select">
                                <input type="text" class="form-control" name="training_title" placeholder="ENTER TRAINING TITLE" value="<?php echo $_REQUEST['training_title']; ?>">
                            </div> 
                            <div class="input-box-select">
                                <!-- <div class="selection-box "> -->
                                    <select name="category" class="form-control" id="dropDown">
                                        <option value="" selected="">PROFESSION</option>
                                        <?php foreach($category as $cate) { ?>
                                        <option value="<?php echo  $cate['id']; ?>"><?php echo  $cate['cat_name']; ?></option>
                                        <?php } ?>  
                                    </select>
                                <!-- </div> -->
                            </div>   
                           <div class="input-box-select"> 
                              <div class="text-box ">
                                    <input type="month"  name="start_date" class="form-control" id="start_date" placeholder="TRAINING DATE" autocomplete="off" >
                              </div>
                           </div>

                            <div class="input-box-select">
                            <!-- <div class="selection-box "> -->
                                    <select name="country" class="form-control" id="countryDropDown" >         
                                        <option value="" selected="">COUNTRY</option>
                                        <?php foreach($countries as $country){ ?>
                                        <option value="<?php echo  $country['countries_id']; ?>">
                                            <?php echo  $country['countries_name']; ?>                      
                                        </option>
                                        <?php } ?>  
                                    </select>
                            <!-- </div> -->
                            </div> 
                             <div class="input-box-select">
                                    <select name="country" class="form-control" id="specificLocation" >         
                                        <option value="">SPECIFIC LOCATION</option>
                                    </select>
                            </div> 

                            <div class="input-box-select">
                                <a href="javascript:void(0)" onclick="jQuery('#trainingform').submit();" class="btn search"><i class="fa fa-search" aria-hidden="true"></i> SEARCH</a>
                            </div>
                    </form>
                    
                </div>
            <?php if(count($seminar) > 0 ){  ?>
              <div class="owl-carousel-3">                 


            <?php  foreach($seminar as $key => $value) {    ?>
            <?php $Profession = $this->db->get_where('tbl_category',array('id'=>$value['category_id']))->row_array()['cat_name'];
                  $ceprovider = $this->db->get_where('tbl_user',array('id'=>$value['user_id']))->row_array()['name'];?>    
                <div class="item">
                    <div class="course-item">
                        <div class="course-double">
                        <?php if($value['paid_status']==2) { ?>
                               <div class="corner"></div>
                               <span class="corner-text">featured</span>
                        <?php  }  ?>
                            <a href="<?php echo site_url('pages/training_details/').$value['id'];?>" class="course-image">
                            <img style="height:298px" src="<?php echo ASSETS_URL.'images/uploads/'.$value['image'];?>" alt="" onError="this.onerror=null;this.src='<?php echo ASSETS_URL; ?>images/uploads/IMG_1560995024.png';" >
                           </a>
                            <div class="dt-sc-course-details">

                                <div class="course-price">$<?php echo $value['price'];?></div>

                                <h5><a href="<?php echo site_url('pages/training_details/').$value['id'];?>" title="<?php echo $value['title'] ?>"><?php echo $value['title'] ?></a></h5>

                                <div class="clear-line"> </div>

                                 <ul class="course-meta">
                                    <li><i class="fa fa-calendar"></i>
                                        <?php echo $value['start_date'];?> @
                                        <?php echo $value['start_time'];?></li>
                                    </ul>
                                    <ul class="course-meta pb-10">
                                        <li>
                                            <i class="fa fa-map-marker"></i>
                                        <?php echo $value['location'];?>
                                        </li>
                                </ul>
                                <!-- <p><?php echo substr(strip_tags($value['description']),0,35);?>...</p> -->
                                <p title="<?php echo $Profession; ?>">Professions : <?php echo substr($Profession,0,10); ?></p>
                                <p title="<?php echo $ceprovider; ?>">CEprovider : <?php echo $ceprovider; ?></p>
                                <p>CE Unit : <?php echo $value['units']; ?></p>
                               

                                <div class="course-data">
                                    <div class="course-duration"><i class="fa fa-list-ol"> </i> CE Units <?php echo $value['units'];?></div>
                                    <div class="post-ratings">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star-o" aria-hidden="true"></i>
                                        <i class="fa fa-star-o" aria-hidden="true"></i>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>
                <?php } ?>
             
                </div>
                <?php }else{ echo '<center>No Data found!</center>'; }  ?>

            </div>
        </div>
    </div>
</div>
<?php /*
        <section class="bottome-addspace" style="padding: 10px 10px">
        <?php if(!empty($current_country)){ $this->db->where('tbl_adv_package_purchased.country',$current_country); }
                 $middlebanner = $this->advertiseads->getAdvertiserBanner('Middle Body');                       
                  if(count($middlebanner))
                   {
                      foreach($middlebanner as $banner)
                      {
                          $this->advertiseads->updateCount($banner['id']);
                          $size=explode('x',$banner['size']);
                          ?>
                            <div class="item">
                                <div class="container">
                                    <div class="bottome-addspace-box">
                                        <a href="<?php if($banner['website_url']){ echo $banner['website_url'];}else{ echo "#";}?>"><img src="<?php echo ASSETS_URL.'upload/'.$banner['banner_image'];?>" width="<?php echo $size[0]; ?>" height="<?php echo $size[1]; ?>" alt=""></a>
                                    </div>
                                </div>
                            </div>
            <?php break; }
                   }else{ ?>
                       <div class="item">
                            <div class="container px-0">
                                <div class="bottome-addspace-box">
                                    <img src="<?php echo ASSETS_URL.'images/advertise/new-1230-x-200.jpg';?>"  alt="">
                                </div>
                            </div>
                        </div>
               <?php } ?>       
        </section>
*/ ?>

<div class="newsletter-section">
    <div class="container">
        <div id="newsletter">

            <h3 class="text-white">Renewing your Professional License? </h3>
            <h3 class="text-white">Ready for you Job Performance Appraisal?</h3>
            <h2>GET CE UNITS OR CONTACT HOURS NOW!</h2>
            
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="online-box">
                        <a href="<?php echo site_url('pages/courses');?>">
                            <div class="online-img">
                                <img src="<?php echo base_url('assets/images/online.png'); ?>" alt="Online Courses">
                            </div>
                            <div class="online-text">
                                <p>ONLINE COURSES</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="online-box">
                        <a href="<?php echo site_url('pages/training'); ?>">
                            <div class="online-img">
                                <img src="<?php echo base_url('assets/images/traning.png'); ?>" alt="Training">
                            </div>
                            <div class="online-text">
                                <p>TRANING / SEMINARS</p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="online-box">
                         <a href="javascript:void(0)" onclick="checklogin();">
                        <!--<a href="<?php echo site_url('pages/cfvalidation'); ?>">-->
                        <div class="online-img">
                            <img src="<?php echo base_url('assets/images/certificates.png'); ?>" alt="Certificates">
                        </div>
                        <div class="online-text">
                            <p>UPLOAD CERTIFICATES</p>
                        </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="online-box">
                        <a href="<?php echo site_url('pages/Institutionspage'); ?>">
                            <div class="online-img">
                                <img src="<?php echo base_url('assets/images/institute.png'); ?>" alt="Institutes">
                            </div>
                            <div class="online-text">
                                <p>INSTITUTION CE WEBPAGE</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>


            <!-- <h2>Track your Professional License? Get CE Units online!</h2>
            <h6>Choose Online CE Courses anytime, anywhere at any device!</h6> 
            <a href="<?php echo site_url('pages/courses');?>" class="btn btn-default btn-lg"><i class="fa fa-thumbs-o-up"></i>  VIEW ONLINE CE COURSES!</a> -->

        </div>
    </div>
</div>



<section class="pb-3 latest-Professionals">

    <div class="container">
        <div class="row">

            <div class="col-md-9">
                <h3 class="border-title border-title-h text-left">Latest Professionals</h3>
                <?php if(count($latestprofessionallist)>0){ ?>
                <button class="btn btn-warning pull-right"><a class="text-white" href="<?php echo base_url('pages/latestprofessional'); ?>"  >View All Professionals</a></button><?php } ?>
            </div>
            <div class="col-md-3">
                <h3 class="border-title border-title-h text-left">NEWS/BLOG</h3>
                <?php if(count($blogs)>0){ ?>
                <button class="btn btn-info pull-right"><a class="text-white" href="<?php echo base_url('pages/blog'); ?>">View All</a></button><?php } ?>
            </div>   
                    
            <div class="col-md-9">
            <?php if(count($latestprofessionallist)>0){ ?>
            <div class="owl-carousel-3">
            <?php foreach($latestprofessionallist as $latpro){ 
                $profileimg = $this->db->get_where('tbl_user',array('id'=>$latpro['user_id']))->row_array()['image']; 
                $country = $this->db->get_where('countries',array('countries_id'=>$value['country_id']))->row_array()['countries_name'];?>
            <div class="item">
                <div class="new-training-box">
                    <?php if(date('Y-m-d') >=$latpro['featured_from'] and date('Y-m-d')<=$latpro['featured_to']){ ?>
                        <div class="corner"></div>
                        <span class="corner-text">featured</span>
                    <?php } ?> 
                    <a href="<?php echo site_url('share/viewprofile/').$latpro['user_id']; ?>">
                        <div class="training-box_overlay"></div>
                        <div class="training-box-image prof_images">
                            <img src="<?php echo ASSETS_URL."images/uploads/".$profileimg; ?>" onError="this.onerror=null;this.src='<?php echo ASSETS_URL."images/dummy-profile.jpg"; ?>';" alt="">
                        </div>
                        <div class="training-box-caption">
                            <h5 class="training-box_title"><?php echo $latpro['name']; ?></h5>
                            <div class="training-box_text"><?php echo $latpro['profession'].'<br>'.$country; ?></div>
                        </div>
                    </a>
                </div>
            </div>
            <?php } ?>
            </div>
            <?php }else{ echo 'No Data found!'; } ?>
            </div>

           
            <div class="col-md-3">
            <?php if(count($blogs)>0){ ?>
            <div class="owl-blog">
            <?php foreach($blogs as $blog){ ?>
            <div class="owl-item-blog">
                <div class="new-training-box">
                    <a href="<?php echo site_url('pages/blog_details/').$blog['id']; ?>">
                        <div class="training-box_overlay"></div>
                        <div class="training-box-image blog_images">
                            <img src="<?php echo ASSETS_URL."upload/blog/".$blog['image']; ?>" onError="this.onerror=null;this.src='<?php echo ASSETS_URL."images/dummy-profile.jpg"; ?>';" alt="">
                        </div>
                        <div class="training-box-caption">
                            <h5 class="training-box_title"><?php echo $blog['title']; ?></h5>
                            <!-- <div class="training-box_text"><?php echo $blog['st_desc']; ?></div> -->
                            <a href="<?=base_url('pages/blog_details/'.$blog['id'])?>" class="read-button">Read More</a>
                        </div>
                    </a>
                </div>
            </div>
            <?php } ?>
            </div>
            <?php }else{ echo '<center><b>No Data found!</b></center>'; } ?>
            </div>
                
                    
            <div class="col-md-7 pb-3">
                <h3 class="border-title border-title-h text-left">Latest CE Providers</h3>
                <?php 
                $this->db->where(array('under_insititution'=>0,'parent_insititution'=>0,'status'=>'1'));
                $provider = $this->user->getProviders('');
                // print_r(count($provider));

                if(count($provider)>0){ ?><button class="btn btn-primary pull-right"><a class="text-white" href="<?php echo base_url('pages/ceprovider'); ?>"  >View All CE Providers</a></button><?php } ?>
         
                <div class="training-semi-slider-6 pagi-above">
                <?php if(count($provider)>0){ 
                 foreach ($provider as $key => $value) { 
                    $country = $this->db->get_where('countries',array('countries_id'=>$value['country']))->row_array()['countries_name'];?>
                    <div class="item">
                        <div class="training-semi">
                            <div class="new-training-box">
                            <?php if(date('Y-m-d') >=$value['featured_from'] and date('Y-m-d')<=$value['featured_to']) { ?>
                                <div class="corner"></div>
                                <span class="corner-text">featured</span>
                            <?php } ?>
                                <!-- <a href="<?php echo site_url('provider/viewmypage/'.$value['id'].'');?>"> -->
                                <a href="<?php echo site_url('share/viewprofile/'.$value['id'].'');?>">
                                    <div class="training-box_overlay"></div>
                                    <div class="training-box-image provider_images">

                                        <?php if($value['image']==""){
                                                $img = "dummy-profile.jpg";
                                            }else{
                                                $img = $value['image'];
                                            }?>

                                        <img src="<?php echo ASSETS_URL.'images/uploads/'.$img; ?>" alt="<?php echo $img;?>" title="<?php echo $img;?>">
                                    </div>
                                    <div class="training-box-caption">
                                        <h5 class="training-box_title"><?php echo $value['name']; ?></h5>
                                        <div class="training-box_text"><?php echo $country; ?></div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php } }else{ echo 'No Data Found!'; } ?>  
              </div>


            <h3 class="border-title border-title-h text-left">Latest CE Authors</h3>
            <?php if(count($authors) > 0 ){ ?><button class="btn btn-danger pull-right"><a class="text-white" href="<?php echo base_url('pages/authors'); ?>"  >View All Authors</a></button><?php } ?>
              <div class="training-semi-slider-6 pagi-above">
                <?php if(count($authors) > 0 ){ 
                 foreach ($authors as $key => $value) { 
                 $profileimg = $this->db->get_where('tbl_user',array('id'=>$value['user_id']))->row_array()['image']; 
                 $country = $this->db->get_where('countries',array('countries_id'=>$value['country']))->row_array()['countries_name'];?>
                    <div class="item">
                        <div class="training-semi">
                            <div class="new-training-box">
                            <?php if(date('Y-m-d') >=$value['featured_from'] and date('Y-m-d')<=$value['featured_to']) { ?>
                                <div class="corner"></div>
                                <span class="corner-text">featured</span>
                            <?php } ?>
                                <a href="<?php echo base_url('share/viewprofile/').$value['id'];?>">
                                    <div class="training-box_overlay"></div>
                                    <div class="training-box-image author_images">

                                        <?php if($value['image']==""){
                                            $img = "dummy-profile.jpg";
                                        } else {
                                            $img = $value['image'];
                                        }?>

                                        <img src="<?php echo ASSETS_URL.'images/uploads/'.$img;?>" alt="<?php echo $img;?>" title="<?php echo $img;?>">
                                    </div>
                                    <div class="training-box-caption">
                                        <h5 class="training-box_title"><?php echo $value['name']; ?></h5>
                                        <div class="training-box_text"><?php echo $country; ?></div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php } }else{ echo 'No Data Found!'; } ?>  
              </div>
              
            </div>

            <div class="col-md-5 pb-3">
                <h3 class="border-title border-title-h text-left">Latest Institution</h3>
                <?php // $instite = $this->user->get_record_by_field_name_all_record('tbl_user','role',5);
                        // $this->db->where('status','1');
                      $instite = $this->user->getInstitutions('');
                      if(count($instite)>0){ ?>
                <button class="btn btn-success pull-right"><a class="text-white" href="<?php echo base_url('pages/Institutionspage'); ?>" >View All Institutions</a></button> <?php } ?>

                <div class="training-semi-slider-7 pagi-above">
                <?php 
                    if(count($instite)>0){
                    foreach ($instite as $key => $value) {   
                    $country = $this->db->get_where('countries',array('countries_id'=>$value['country']))->row_array()['countries_name']; ?>
                    <div class="item">
                        <div class="training-semi training-semi-big">
                            <div class="new-training-box">
                                <a href="<?php echo site_url('web/').$value['insititution_id']; ?>">
                                    <div class="training-box_overlay"></div>
                                    <div class="training-box-image ins_images">

                                        <?php    if($value['backimage']==""){
                                                    $img = "dummy-profile.jpg";
                                                 } else {
                                                    $img = $value['backimage'];
                                                }  ?>
                                    <img src="<?php echo ASSETS_URL.'images/uploads/'.$img;?>" alt="<?php echo $img;?>" title="<?php echo $img;?>">
                                    </div>
                                    <div class="training-box-caption">
                                        <h5 class="training-box_title"><?php echo $value['name']; ?></h5>
                                        <div class="training-box_text"><?php echo $country; ?></div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php  }  ?>
                <?php  }else{ echo 'No Data Found!'; } ?>
                </div>
            </div>

  <?php /*
        <div class="col-md-12">
        <div class="main-addspace">
        <div class="text-left" style="">Advertisement:</div>
            <div class="main-addspace-box">
                                        <?php 
                        if(!empty($current_country)){$this->db->where('tbl_adv_package_purchased.country',$current_country);}
                                    $bottombanner = $this->advertiseads->getAdvertiserBanner('Bottom Body');                        
                                    if(count($bottombanner))
                                    {
                                        $i=1;
                                        foreach($bottombanner as $banner)
                                        {
                                            if($i>4)
                                        {
                                            break;
                                        }
                                            $i++;
                                   $this->advertiseads->updateCount($banner['id']);
                                  $size=explode('x',$banner['size']);
                                  ?>
                                     
                                        <div class="item">
                                            <div class="main-addspace-iner-box">
                                                <a href="<?php if($banner['website_url']){ echo $banner['website_url'];}else{ echo "#";}?>">
                                                <img src="<?php echo ASSETS_URL.'upload/'.$banner['banner_image'];?>" width="<?php echo $size[0]; ?>" height="<?php echo $size[1]; ?>" alt=""></a>
                                            </div>
                                        </div>
                        <?php     }
                                }else { ?>
                                        <a href="#">
                                        <div class="item">
                                            <div class="main-addspace-iner-box">
                                                <img src="<?php echo ASSETS_URL.'images/advertise/new-300-x-50.jpg'; ?>" alt="">
                                            </div>
                                        </div>
                                        </a>
                                   
                                        <a href="#">
                                        <div class="item">
                                            <div class="main-addspace-iner-box">
                                                <img src="<?php echo ASSETS_URL.'images/advertise/new-300-x-50.jpg'; ?>" alt="">
                                            </div>
                                        </div>
                                        </a>
                                    
                                        <a href="#">
                                        <div class="item">
                                            <div class="main-addspace-iner-box">
                                                <img src="<?php echo ASSETS_URL.'images/advertise/new-300-x-50.jpg'; ?>" alt="">
                                            </div>
                                        </div>
                                        </a>
                                   
                                        <a href="#">
                                        <div class="item">
                                            <div class="main-addspace-iner-box">
                                                <img src="<?php echo ASSETS_URL.'images/advertise/new-300-x-50.jpg'; ?>" alt="">
                                            </div>
                                        </div>
                                        </a>
                                    
                    <?php } ?>
                </div>
            </div>
        
        </div>
        */ ?>
        </div>
    </div>
</section>
 

<style type="text/css">
.owl-carousel-blog{
  transform: rotate(90deg);
  width: 270px; 
  margin-top:100px;
} 
.item-blog{
  transform: rotate(-90deg);
}
.owl-carousel-blog .owl-nav{
  display: flex;
  justify-content: space-between;
  position: absolute;
  width: 100%;
  top: calc(50% - 33px);
}
div.owl-carousel-blog .owl-nav .owl-prev, div.owl-carousel-blog .owl-nav .owl-next{
    font-size:36px;
    top:unset;
    bottom: 15px; 
}
</style>

    <script>
    $( document ).ready(function() {
        $.ajax({
            type: 'POST',
            url: "<?php echo base_url('pages/viewer_counter'); ?>",
            success:function(result){
            }
        });            

        $(".owl-carousel-blog").owlCarousel({
            items: 2,
            loop: false,
            mouseDrag: true,
            touchDrag: false,
            pullDrag: false,
            rewind: true,
            autoplay: true,
            margin: 1,
            dots: false
            // nav: true
        });
    });

                 
        $('#countryDropDown').change(function(){ 
            var id = $(this).val();
                
                $.ajax({
                    type: 'POST',
                    url: "<?php echo base_url('pages/trainingcountry/'); ?>"+id,
                    data: { 'id' : id },
                        success:function(result){
                            // alert(result);
                        $("#specificLocation").html(result);
                    }
            });
          });
        </script>