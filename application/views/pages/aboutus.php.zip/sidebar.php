
 <div class="col-md-4">
    <div class="sidebar-box">
        <div class="blog-categories">  
        <a class="btn btn-primary" href="<?php echo base_url('users/signup/professional'); ?>" style="margin-bottom: 5px;">REGISTER AS PROFESIONAL</a>
        <a class="btn btn-success" href="<?php echo base_url('users/signup/provider'); ?>" style="margin-bottom: 5px;">
        REGISTER AS CE PROVIDER</a>
        <a class="btn btn-warning" href="<?php echo base_url('users/signup/institution'); ?>" style="margin-bottom: 5px;">REGISTER AS INSTITUTION</a>
        <a class="btn btn-info" href="<?php echo base_url('users/signup/authors'); ?>" style="margin-bottom: 5px;">REGISTER AS AUTHOR</a>
        </div>
        <h3 class="border-title text-left">Advertisement</h3>
    <div class="">
    <?php if(!empty($current_country)){$this->db->where('tbl_adv_package_purchased.country',$this->session->userdata('current_country'));}
        $topbanner = $this->advertiseads->getAdvertiserBanner('Right Side Body');
        if (count($topbanner))
        {
            foreach ($topbanner as $banner)
            {
                $this->advertiseads->updateCount($banner['id']); ?>
                <div class="item">
                <a href="<?php if ($banner['website_url']){ echo $banner['website_url'];
            }else{ echo "#";} ?>"> <img src="<?php echo ASSETS_URL.'upload/advertise/'.$banner['banner_image']; ?>" alt=""></a>
                </div>
                <?php
                break;
            }
        }else{ ?>
        <div class="item"><a href="#"><img src="<?php echo ASSETS_URL.'images/advertise/new-788-x-365.jpg'; ?>" alt=""></a></div>
        <?php
        } ?>
            </div>
                
        <div class=" pt-20">
            <?php if(!empty($current_country)){$this->db->where('tbl_adv_package_purchased.country',$this->session->userdata('current_country'));}
            $topbanner = $this->advertiseads->getAdvertiserBanner('Right Side Body');
            if (count($topbanner))
            {
                foreach ($topbanner as $banner)
                {
                    $this->advertiseads->updateCount($banner['id']); ?>
                    <div class="item">
                        <a href="<?php if ($banner['website_url']){ echo $banner['website_url'];
                                    }else{ echo "#"; } ?>">
                            <img src="<?php echo ASSETS_URL.'upload/'.$banner['banner_image']; ?>" alt="">
                        </a>
                    </div>
                    <?php
                    break;
                }
            }else{ ?>
                    <a href="#" >
                    <div class="item"><img src="<?php echo ASSETS_URL.'images/advertise/new-788-x-365.jpg'; ?>" alt=""></div></a>
            <?php } ?>
        </div>

        <div class="pt-20">
            <?php
            if(!empty($current_country)){$this->db->where('tbl_adv_package_purchased.country',$this->session->userdata('current_country'));}
            $topbanner = $this->advertiseads->getAdvertiserBanner('Right Side Body');
            if (count($topbanner))
            {
                foreach ($topbanner as $banner)
                {
                    $this->advertiseads->updateCount($banner['id']); ?>
                    <div class="item">
                        <a href="<?php if ($banner['website_url']){ echo $banner['website_url'];
                                     }else{ echo "#"; } ?>">
                        <img src="<?php echo ASSETS_URL.'upload/'.$banner['banner_image']; ?>" alt="">
                        </a>
                    </div>
                    <?php
                    break;
                }
            }
            else{ ?>
                <a href="#">
                <div class="item"><img src="<?php echo ASSETS_URL.'images/advertise/new-788-x-365.jpg'; ?>" alt=""></div>
                </a>
                <?php } ?>
        </div>
    </div>
</div>
        
